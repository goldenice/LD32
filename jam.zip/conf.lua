function love.conf(t)
    t.window.width = 960 -- t.screen.width in 0.8.0 and earlier
    t.window.height = 720 -- t.screen.height in 0.8.0 and earlier
    t.window.vsync = false
    t.window.title = "Bullet Rain"
end
