function attack(x , y , patern)


end
