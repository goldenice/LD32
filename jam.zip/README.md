# LD32: An Unconventional Weapon
